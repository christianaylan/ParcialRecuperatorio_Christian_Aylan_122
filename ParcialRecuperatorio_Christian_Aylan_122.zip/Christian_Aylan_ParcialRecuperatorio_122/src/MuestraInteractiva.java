
public class MuestraInteractiva extends Actividad implements Presentable {

    private final int estaciones;
/**
 * crea una muestra interactiva
 * @param codigo codigo de identificacion
 * @param titulo nombre del taller
 * @param franja horario del taller
 * @param duracionBase duracion estimada
 * @param estaciones cantidad de estaciones
 */
    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria franja,
            int duracionBase, int estaciones) {
        super(codigo, titulo, franja, duracionBase);
        validarNumero(estaciones, "Cantidad estaciones");
        this.estaciones = estaciones;
    }

    @Override
    public String presentar() {
        return "Presentacion de muestra: " + getTitulo();
    }

    @Override
    protected String caracteristica() {
        return "estaciones=" + estaciones;
    }

    @Override
    protected int calcularDuracion() {
        return getDuracionBase() + 5 * estaciones;
    }
}
