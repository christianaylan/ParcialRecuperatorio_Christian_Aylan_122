
public interface Presentable {

    public String presentar();
}
