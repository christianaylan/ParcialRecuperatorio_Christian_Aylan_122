
public class ActividadDuplicadaException extends Exception {

    private static final String MESSAGE = "Ya existe la actividad";

    public ActividadDuplicadaException() {
        this(MESSAGE);
    }

    public ActividadDuplicadaException(String mensaje) {
        super(mensaje);
    }

    public ActividadDuplicadaException(String codigo, String titulo) {
        super(MESSAGE + ": " + codigo + " - " + titulo);
    }

}
