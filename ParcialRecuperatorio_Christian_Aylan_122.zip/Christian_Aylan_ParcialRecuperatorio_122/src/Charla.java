
public class Charla extends Actividad implements Reservable, Presentable {

    private final int minutosPreguntas;
    private int cupos;
/**
 * crea una charla
 * @param codigo codigo de identificacion
 * @param titulo nombre de la charla
 * @param franja horario de la charla
 * @param duracionBase duracion estimada
 * @param minutosPreguntas tiempo dedicado a preguntas
 * @param cupos espacios disponibles para reservas
 */
    public Charla(String codigo, String titulo, FranjaHoraria franja, int duracionBase,
            int minutosPreguntas, int cupos) {
        super(codigo, titulo, franja, duracionBase);
        validarNumero(minutosPreguntas, "Tiempo de preguntas");
        validarNumero(cupos, "Cupos disponibles");
        this.minutosPreguntas = minutosPreguntas;
        this.cupos = cupos;
    }

    @Override
    protected String caracteristica() {
        return "tiempoPreguntas=" + minutosPreguntas + " cupos=" + cupos;
    }

    @Override
    public String reservarLugar() {
        if (cupos == 0) {
            throw new IllegalStateException();
        }
        cupos--;
        return "Reserva confirmada para: " + getTitulo() + ". Cupos restantes: " + cupos;
    }

    @Override
    protected int calcularDuracion() {
        return getDuracionBase() + minutosPreguntas;
    }

    @Override
    public String presentar() {
        return getTitulo() + " realiza una presentacion.";
    }

}
