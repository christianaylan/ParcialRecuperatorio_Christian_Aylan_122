
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Festival {

    private final List<Actividad> actividades;
    private final String nombre;

    public Festival(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.actividades = new ArrayList();
    }

    private static void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("Nombre de festival invalido");
        }
    }

    private static void validarNumero(int numero) {
        if (numero <= 0) {
            throw new IllegalArgumentException("Numero invalido");
        }
    }

    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        if (actividades.contains(actividad)) {
            throw new ActividadDuplicadaException(actividad.getCodigo(), actividad.getTitulo());
        }
        actividades.add(actividad);
    }

    /**
     * retorna una copia de la lista de actividades
     */
    public List<Actividad> obtenerActividades() {
        return new ArrayList<>(actividades);
    }

    /**
     * muestra las actividades de una franja horaria especifica
     *
     * @param franjaHoraria tiempo solicitado
     * @return la actividades en esa franja
     */
    public List<Actividad> filtrarPorFranja(FranjaHoraria franjaHoraria) {
        Objects.requireNonNull(franjaHoraria, "Franja horaria nula");
        List<Actividad> resultado = new ArrayList();
        for (Actividad act : actividades) {
            if (act.getFranja() == franjaHoraria) {
                resultado.add(act);
            }
        }
        return resultado;
    }

    /**
     * retorna las actividades que duren menos que al tiempo solicitado
     * @param maxima medida de tiempo buscada
     * @return una lista de actividades
     */
    public List<Actividad> obtenerActividadesDeDuracionMaxima(int maxima) {
        validarNumero(maxima);
        List<Actividad> resultado = new ArrayList();
        for (Actividad act : actividades) {
            if (act.calcularDuracion() < maxima) {
                resultado.add(act);
            }
        }
        return resultado;
    }

}
