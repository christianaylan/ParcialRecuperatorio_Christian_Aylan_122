
public class Taller extends Actividad implements Reservable {

    private final int minutosPractica;
    private int cupos;
/**
 * crea un taller
 * @param codigo codigo de identificacion
 * @param titulo nombre del taller
 * @param franja horario del taller
 * @param duracionBase duracion estimada
 * @param minutosPractica tiempo para la practica
 * @param cupos espacios disponibles para reservas
 */
    public Taller(String codigo, String titulo, FranjaHoraria franja, int duracionBase,
            int minutosPractica, int cupos) {
        super(codigo, titulo, franja, duracionBase);
        validarNumero(minutosPractica, "Tiempo de practicas");
        validarNumero(cupos, "Cupos disponibles");
        this.minutosPractica = minutosPractica;
        this.cupos = cupos;
    }

    public int getMinutosPractica() {
        return minutosPractica;
    }

    @Override
    protected String caracteristica() {
        return "tiempoPractica=" + minutosPractica + " cupos=" + cupos;
    }

    @Override
    public String reservarLugar() {
        if (cupos == 0) {
            throw new IllegalStateException();
        }
        cupos--;
        return "Reserva confirmada para: " + getTitulo() + ". Cupos restantes: " + cupos;
    }

    @Override
    protected int calcularDuracion() {
        return getDuracionBase() + minutosPractica;
    }

}
