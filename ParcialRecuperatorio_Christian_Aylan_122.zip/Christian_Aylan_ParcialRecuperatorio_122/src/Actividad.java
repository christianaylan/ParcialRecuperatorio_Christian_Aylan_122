
import java.util.Objects;

public abstract class Actividad {

    private final String codigo;
    private final String titulo;
    private final FranjaHoraria franja;
    private final int duracionBase;

    public Actividad(String codigo, String titulo, FranjaHoraria franja,
            int duracionBase) {
        validarTexto(codigo, "Codigo");
        validarTexto(titulo, "Titulo");
        Objects.requireNonNull(franja, "Franja horaria nula");
        validarNumero(duracionBase, "Duracion base");
        this.codigo = codigo;
        this.titulo = titulo;
        this.franja = franja;
        this.duracionBase = duracionBase;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public FranjaHoraria getFranja() {
        return franja;
    }

    public int getDuracionBase() {
        return duracionBase;
    }

    protected static void validarTexto(String texto, String campo) {
        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException("Palabra invalida en " + campo);
        }
    }

    protected static void validarNumero(int numero, String campo) {
        if (numero <= 0) {
            throw new IllegalArgumentException("Numero invalido en " + campo);
        }
    }

    @Override
    public boolean equals(Object obj) {
        return obj == this || (obj instanceof Actividad otra
                && otra.getCodigo().equals(codigo) && otra.getTitulo().equals(titulo));
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, titulo);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " {codigo=" + codigo + ", titulo=" + titulo
                + ", franja=" + franja + ", duracionBase=" + duracionBase
                + ", " + caracteristica() + '}';
    }

    protected abstract String caracteristica();

    protected abstract int calcularDuracion();
}
