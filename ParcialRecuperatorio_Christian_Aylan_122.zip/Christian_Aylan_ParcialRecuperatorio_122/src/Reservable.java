
public interface Reservable {

    public String reservarLugar();
}
